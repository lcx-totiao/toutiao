var s=WScript.Arguments
var g=new ActiveXObject("ADODB.Stream")
var x=new ActiveXObject("Microsoft.XMLHTTP")
x.Open("GET",s(0).toLowerCase(),0)
x.send()
g.mode=3
g.type=1
g.open()
g.write(x.ResponseBody)
g.SaveToFile(s(1).toLowerCase(),2)